# Unified Figure Color Palette

This version keeps the user-provided `figures/fig1.pdf` unchanged and recolors Fig. 2 and Fig. 3 to match the blue-green/amber academic palette used in Fig. 1.

- FT-HSBO: deep blue (#1F4E99)
- Max-Rate: muted amber (#D07B28)
- EDF: muted red (#BA4148)
- DE-rp: green (#3E8C5D)
- Full BO: neutral gray (#727272)
- Fig. 2 scale bars: light blue (#B2C9E6) for 40-D and light amber (#EEBB72) for 80-D
- Grid lines: pale blue-gray (#D5DCE4)

No text, table, caption, citation, or numerical content was changed in this color-unified version.
