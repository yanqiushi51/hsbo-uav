# Change Log

This package applies text and figure polishing edits that do not depend on the pending 20-seed results.

Main edits:
- Rebuilt Fig. 1 with consistent notation: `s_{ik}`, `R_{ij}(s_{ik})`, `U(x)`, and no placeholder ellipses.
- Weakened over-strong wording around packet-size information and full-space BO zero-dominance.
- Added a clear gap sentence in the Introduction.
- Standardized the time-varying completion expression as an integral with `\mathrm{d}t`.
- Added a concrete definition of intra-UAV slot conflicts in `C_conf`.
- Added an implementation clarification that each FT-HSBO iteration consumes exactly one black-box evaluation.
- Added stress-setting explanation for `R_min=15 Mbps` and completion-gate dominance.
- Added `Win. hit` definition and explanation for the higher 80-D window-hit ratio.
- Removed the unsupported GA/PSO/CMA-ES tested-but-not-shown statement and the unused CMA-ES reference.
- Softened sensitivity wording from absolute best to highest mean utility.
- Added protocol consistency wording for the LoS/NLoS robustness test.
- Adjusted the conclusion to emphasize the larger 80-D setting.

Remaining result-dependent placeholders to update after experiments finish:
- 20-seed Table III values and percentages in the abstract/main text.
- 50000-sample sparsity audit values in Table II.
- Optional served-priority standard deviations, success-rate column, and paired-test statements.
